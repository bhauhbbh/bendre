import{j as r,h as s,e as n,k as e,t as l,l as o,m as c}from"./THSXKwr_.js";const k=r("page",{state:()=>({pageData:{about:{title:"About Bendre PU College",content:`
          <h2>Excellence in Education</h2>
          <p>At Bendre PU College, we are committed to providing exceptional educational experiences that prepare students for success in their academic and professional lives.</p>
          <h3>Our Legacy</h3>
          <p>Founded in 1980, our institution has grown to become a leading center of learning, known for its academic excellence and holistic approach to education.</p>
          <h3>Our Commitment</h3>
          <p>We are dedicated to nurturing young minds, fostering creativity, and building character through a combination of rigorous academic programs and enriching extracurricular activities.</p>
        `,image:"/bendre_.jpg"},academics:{title:"Academic Programs",content:`
          <h2>Excellence in Education</h2>
          <p>At Bendre PU College, we offer a wide range of academic programs designed to challenge and inspire our students. Our curriculum is carefully crafted to provide a strong foundation in core subjects while encouraging critical thinking and creativity.</p>
          <h3>Our Programs</h3>
          <ul>
            <li>Science Stream (PCMB, PCMC)</li>
            <li>Commerce Stream</li>
            <li>Arts Stream</li>
          </ul>
          <p>Each program is taught by experienced faculty members who are passionate about their subjects and dedicated to student success.</p>
        `,image:"/academics.jpg"},"student-life":{title:"Student Life at Bendre PU College",content:`
          <h2>A Vibrant Campus Community</h2>
          <p>Life at Bendre PU College extends far beyond the classroom. We believe in nurturing well-rounded individuals by providing a rich tapestry of extracurricular activities and experiences.</p>
          <h3>Key Aspects of Student Life</h3>
          <ul>
            <li>Student Clubs and Organizations</li>
            <li>Sports and Fitness Facilities</li>
            <li>Cultural Events and Festivals</li>
            <li>Community Service Opportunities</li>
          </ul>
          <p>Our campus buzzes with energy as students engage in various activities, fostering friendships, leadership skills, and personal growth.</p>
        `,image:"/student-life.jpg"},admissions:{title:"Admissions",content:`
          <h2>Join Our Community of Learners</h2>
          <p>We welcome ambitious and curious minds to join our esteemed institution. The admission process at Bendre PU College is designed to be transparent and merit-based.</p>
          <h3>Admission Process</h3>
          <ol>
            <li>Online Application Submission</li>
            <li>Entrance Examination</li>
            <li>Document Verification</li>
            <li>Personal Interview</li>
            <li>Merit List Publication</li>
          </ol>
          <p>We encourage prospective students to visit our campus and get a firsthand experience of our facilities and vibrant community.</p>
        `,image:"/admissions.jpg"},hostel:{title:"Hostel Facilities",content:`
          <h2>A Home Away From Home</h2>
          <p>Bendre PU College offers comfortable and secure hostel facilities for both boys and girls. Our hostels are designed to provide a conducive environment for academic pursuits and personal growth.</p>
          <h3>Separate Hostels for Boys and Girls</h3>
          <p>We maintain separate hostel buildings for male and female students, ensuring privacy and comfort for all residents.</p>
          <h3>Boys' Hostel</h3>
          <ul>
            <li>Modern, well-ventilated rooms</li>
            <li>24/7 security and CCTV surveillance</li>
            <li>Common room with recreational facilities</li>
            <li>High-speed Wi-Fi connectivity</li>
          </ul>
          <h3>Girls' Hostel</h3>
          <ul>
            <li>Comfortable, furnished rooms</li>
            <li>Dedicated warden and female security staff</li>
            <li>Indoor gym and yoga room</li>
            <li>Study areas on each floor</li>
          </ul>
          <p>Both hostels provide nutritious meals, laundry services, and regular cultural activities to ensure a homely atmosphere for our students.</p>
        `,image:"/hostel.jpg"},library:{title:"Library Resources",content:`
          <h2>Expand Your Knowledge</h2>
          <p>The Bendre PU College library is a treasure trove of knowledge, housing an extensive collection of books, journals, and digital resources. Our state-of-the-art facility is designed to support academic research and foster a love for reading.</p>
          <h3>Library Features</h3>
          <ul>
            <li>Vast collection of textbooks and reference materials</li>
            <li>Digital library with access to online journals and e-books</li>
            <li>Quiet study areas and group discussion rooms</li>
            <li>Regular book clubs and literary events</li>
            <li>Knowledgeable librarians to assist with research</li>
          </ul>
          <p>We continually update our collection to ensure our students have access to the latest information in their fields of study.</p>
        `,image:"/library.jpg"},"sports-facilities":{title:"Sports Facilities",content:`
          <h2>Nurturing Athletic Excellence</h2>
          <p>At Bendre PU College, we believe in the importance of physical education alongside academic pursuits. Our world-class sports facilities cater to a wide range of athletic interests and skill levels.</p>
          <h3>Our Sports Infrastructure</h3>
          <ul>
            <li>Olympic-sized swimming pool</li>
            <li>Multi-purpose indoor stadium for basketball, volleyball, and badminton</li>
            <li>State-of-the-art fitness center with trained instructors</li>
            <li>Outdoor track and field facilities</li>
            <li>Cricket ground with practice nets</li>
            <li>Tennis and table tennis courts</li>
          </ul>
          <p>We encourage all students to participate in sports activities, fostering teamwork, discipline, and a healthy lifestyle. Regular inter-college tournaments and sports meets are organized to promote competitive spirit.</p>
        `,image:"/sports.jpg"}}}),actions:{async getPageData(t){return new Promise(a=>{setTimeout(()=>{a(this.pageData[t]||null)},100)})}}}),d={key:0,class:"dynamic-page container mx-auto px-4 py-8"},u={class:"text-3xl font-bold mb-6 text-custom-maroon"},m={class:"flex flex-col md:flex-row gap-8"},p={class:"md:w-2/3"},g=["innerHTML"],h={class:"md:w-1/3"},f=["src","alt"],b={key:1,class:"container mx-auto px-4 py-8"},S={__name:"DynamicPage",props:{pageData:{type:Object,required:!0}},setup(t){return(a,i)=>t.pageData?(s(),n("div",d,[e("h1",u,l(t.pageData.title),1),e("div",m,[e("div",p,[e("div",{innerHTML:t.pageData.content,class:"prose max-w-none"},null,8,g)]),e("div",h,[e("img",{src:t.pageData.image,alt:t.pageData.title,class:"w-full h-auto rounded-lg shadow-lg"},null,8,f)])])])):(s(),n("div",b,i[0]||(i[0]=[e("p",null,"Page not found",-1)])))}},y={key:0,class:"hostel-page container mx-auto px-4 py-8"},v={class:"text-3xl font-bold mb-6 text-custom-maroon"},w={class:"flex flex-col md:flex-row gap-8"},x={class:"md:w-2/3"},C=["innerHTML"],_={class:"md:w-1/3"},P=["src","alt"],O={__name:"HostelPage",props:{pageData:{type:Object,required:!0}},setup(t){return(a,i)=>t.pageData?(s(),n("div",y,[e("h1",v,l(t.pageData.title),1),e("div",w,[e("div",x,[e("div",{innerHTML:t.pageData.content,class:"prose max-w-none"},null,8,C)]),e("div",_,[e("img",{src:t.pageData.image,alt:t.pageData.title,class:"w-full h-auto rounded-lg shadow-lg mb-6"},null,8,P),i[0]||(i[0]=e("div",{class:"bg-gray-100 p-4 rounded-lg"},[e("h3",{class:"text-xl font-semibold mb-2"},"Hostel Contact Information"),e("p",null,[e("strong",null,"Warden:"),o(" Mr. John Doe")]),e("p",null,[e("strong",null,"Phone:"),o(" +91 9876543210")]),e("p",null,[e("strong",null,"Email:"),o(" hostel@bendrepucollege.edu")])],-1))])])])):c("",!0)}};export{S as _,O as a,k as u};
